$(document).ready(function() {
    $('a.btn-delete').on('click', function(e) {
        console.log('fdsaf');
        e.preventDefault();
        $('#deleteModal form').attr('action', $(this).data('delete'));
    });

    $('.upload_thumbnail').change(function() {
        if (this.files && this.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#thumbnail').attr('src', e.target.result);
            };

            reader.readAsDataURL(this.files[0]);
        }
    });
});